USE assignment;
SET SQL_SAFE_UPDATES=0;
# ------- to check the imported tables
select* from bajaj_auto;
select* from eicher_motors;
select* from hero_motocorp;
select* from infosys;
select* from tcs;
select* from tvs_motors;

#----- change the datatype of date in the date column of the data 

UPDATE `bajaj_auto` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `bajaj_auto` MODIFY COLUMN `Date` date;

#----- to check whether the format is changed or not
select* from bajaj_auto;

UPDATE `eicher_motors` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `eicher_motors` MODIFY COLUMN `Date` date;
select* from eicher_motors;

UPDATE `hero_motocorp` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `hero_motocorp` MODIFY COLUMN `Date` date;
select* from hero_motocorp;

UPDATE `infosys` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `infosys` MODIFY COLUMN `Date` date;
select* from infosys;

UPDATE `tcs` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `tcs` MODIFY COLUMN `Date` date;
select* from tcs;

UPDATE `tvs_motors` SET `Date` = str_to_date(`Date`, '%d-%M-%Y');
ALTER TABLE `tvs_motors` MODIFY COLUMN `Date` date;
select* from tvs_motors;

#------------Create Table bajaj1
CREATE TABLE bajaj1 AS
SELECT `Date`, `Close Price`,

AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `bajaj_auto`;
#----check table
SELECT * FROM bajaj1;

#-------Create Table eicher1
 
CREATE TABLE eicher1 AS
SELECT `Date`, `Close Price`,


AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `eicher_motors`;
#---- check table
SELECT * FROM eicher1;

#-------Create Table hero1
CREATE TABLE hero1 AS
SELECT `Date`, `Close Price`,


AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `hero_motocorp`;

#---check table
select* from hero1;

#----Create Table infosys;
CREATE TABLE infosys1 AS
SELECT `Date`, `Close Price`,


AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `infosys`;

#--check table
SELECT * FROM infosys1;

#----- Create Table tcs
CREATE TABLE tcs1 AS
SELECT `Date`, `Close Price`,


AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `tcs`;

#-- check table
select * from tcs1;


#----Create Table tvs1
CREATE TABLE tvs1 AS
SELECT `Date`, `Close Price`,


AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 19 FOLLOWING) AS `20 Day MA` ,
AVG(`Close Price`) OVER (ROWS BETWEEN 0 preceding AND 49 FOLLOWING) AS `50 Day MA`
FROM  `tvs_motors`;

#-----check table
select* from tvs1;


#--------Creating the master table which consists the close price of the shares

CREATE TABLE master_table AS
SELECT b.`Date`, b.`Close Price` as Bajaj, 
       tc.`Close Price` AS TCS, 
       tv.`Close Price` AS TVS, 
       i.`Close Price`	 AS Infosys, 
       e.`Close Price`  AS Eicher, 
       h.`Close Price`	AS Hero
FROM bajaj1 b INNER JOIN tcs1 tc ON 	b.`Date` = tc.`Date`
INNER JOIN tvs1 tv ON 	b.`Date` = tv.`Date`
INNER JOIN infosys1 i ON  b.`Date` = i.`Date`
INNER JOIN eicher1 e ON	b.`Date` = e.`Date`
INNER JOIN hero1 h ON     b.`Date` = h.`Date` ;

#---check table
select* from master_table ;

#--- creating the tables to check the signal(Buy/Sell/Hold)
#BAJAJ2
CREATE TABLE bajaj2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM bajaj1 ;
#-----check table
select* from bajaj2;

#EICHER2
CREATE TABLE eicher2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM eicher1 ;
#----check table
select* from eicher2;

#-----HERO2
CREATE TABLE hero2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM hero1 ;
#--check table
select* from hero2;

#----INFOSYS2
CREATE TABLE infosys2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM infosys1 ;
#--check table
select* from infosys2;

#---TCS2
CREATE TABLE tcs2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM tcs1 ;
#--check table
select* from tcs1;

#----TVS2
CREATE TABLE tvs2 AS
SELECT `Date`, `Close Price`,
	CASE
		WHEN (`20 Day MA` > `50 Day MA`)   THEN 'Buy'
		WHEN (`20 Day MA` < `50 Day MA`)   THEN 'Sell'
		ELSE 'Hold'
	END AS `Signal`
FROM tvs1 ;
#---check table
select* from tvs2; 

-- create user defined function to check the signal for a particular day of bajaj share

delimiter $$
CREATE FUNCTION generate_signal( dt char(20))
RETURNS char(20)
DETERMINISTIC
BEGIN
RETURN (SELECT `Signal` FROM bajaj2 WHERE `Date` = dt);
END $$
delimiter ;

-- sample input to check the user defined function
SELECT generate_signal('2017-9-8') AS Signal_generated;



